/**
 * WebP Forge — popup.js
 * Client-side image → WebP converter + compressor
 * Uses Canvas API for conversion; no server required.
 */

'use strict';

/* ══════════════════════════════════════════════════════════════
   DOM REFERENCES
══════════════════════════════════════════════════════════════ */
const dropZone        = document.getElementById('drop-zone');
const fileInput       = document.getElementById('file-input');
const sizeSelect      = document.getElementById('size-select');
const customSizeWrap  = document.getElementById('custom-size-wrap');
const customSizeInput = document.getElementById('custom-size');
const resizeSelect    = document.getElementById('resize-select');

const uploadSection   = document.getElementById('upload-section');
const queueSection    = document.getElementById('queue-section');
const resultsSection  = document.getElementById('results-section');

const queueCount      = document.getElementById('queue-count');
const queueList       = document.getElementById('queue-list');
const convertAllBtn   = document.getElementById('convert-all-btn');
const addMoreBtn      = document.getElementById('add-more-btn');
const addMoreInput    = document.getElementById('add-more-input');

const resultsListEl   = document.getElementById('results-list');
const downloadAllBtn  = document.getElementById('download-all-btn');
const convertMoreBtn  = document.getElementById('convert-more-btn');

const progressOverlay = document.getElementById('progress-overlay');
const progressLabel   = document.getElementById('progress-label');
const progressBar     = document.getElementById('progress-bar');
const progressSub     = document.getElementById('progress-sub');

const canvas          = document.getElementById('convert-canvas');
const ctx             = canvas.getContext('2d');

/* ══════════════════════════════════════════════════════════════
   STATE
══════════════════════════════════════════════════════════════ */
/** @type {{ file: File, objectUrl: string }[]} */
let queue = [];

/** @type {{ name: string, originalSize: number, convertedSize: number, blob: Blob, previewUrl: string }[]} */
let results = [];

/* ══════════════════════════════════════════════════════════════
   ACCEPTED TYPES
══════════════════════════════════════════════════════════════ */
const ACCEPTED_TYPES = new Set([
  'image/jpeg', 'image/png', 'image/gif',
  'image/bmp', 'image/svg+xml', 'image/webp'
]);

/* ══════════════════════════════════════════════════════════════
   HELPERS
══════════════════════════════════════════════════════════════ */

/**
 * Format bytes into KB / MB string.
 * @param {number} bytes
 * @returns {string}
 */
function formatSize(bytes) {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${(bytes / 1024 / 1024).toFixed(2)} MB`;
}

/**
 * Generate an SEO-friendly filename from the original name.
 * @param {string} originalName
 * @returns {string} e.g. "my-photo-optimized.webp"
 */
function seoFilename(originalName) {
  const base = originalName
    .replace(/\.[^.]+$/, '')          // strip extension
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '-')      // non-alphanumeric → dash
    .replace(/^-+|-+$/g, '')          // trim leading/trailing dashes
    .substring(0, 60);                // max 60 chars
  return `${base || 'image'}-optimized.webp`;
}

/**
 * Load a File into an HTMLImageElement.
 * For SVG files we first convert to a data URL.
 * @param {File} file
 * @returns {Promise<HTMLImageElement>}
 */
function loadImage(file) {
  return new Promise((resolve, reject) => {
    const url = URL.createObjectURL(file);
    const img = new Image();
    img.onload  = () => { resolve(img); };
    img.onerror = () => reject(new Error(`Failed to load ${file.name}`));
    img.src = url;
  });
}

/**
 * Get the target file size in bytes.
 * @returns {number}
 */
function getTargetBytes() {
  const val = sizeSelect.value;
  if (val === 'custom') {
    const kb = parseFloat(customSizeInput.value);
    return isNaN(kb) || kb <= 0 ? 100 * 1024 : kb * 1024;
  }
  return parseInt(val, 10) * 1024;
}

/**
 * Get the max output width (0 = keep original).
 * @returns {number}
 */
function getMaxWidth() {
  return parseInt(resizeSelect.value, 10) || 0;
}

/**
 * Binary-search for the WebP quality that produces a blob ≤ targetBytes.
 * Falls back to quality 0.05 if the image can't be compressed enough.
 * @param {HTMLImageElement} img
 * @param {number} drawW  Canvas draw width
 * @param {number} drawH  Canvas draw height
 * @param {number} targetBytes
 * @returns {Promise<Blob>}
 */
async function compressToTarget(img, drawW, drawH, targetBytes) {
  canvas.width  = drawW;
  canvas.height = drawH;

  // Clear canvas
  ctx.clearRect(0, 0, drawW, drawH);

  // White background for transparency-preserving formats
  ctx.fillStyle = '#ffffff';
  ctx.fillRect(0, 0, drawW, drawH);

  ctx.drawImage(img, 0, 0, drawW, drawH);

  // Binary search between quality 0.05 and 1.0
  let lo = 0.05, hi = 1.0, bestBlob = null;

  for (let i = 0; i < 10; i++) {
    const mid = (lo + hi) / 2;
    const blob = await canvasToBlob(mid);
    if (blob.size <= targetBytes) {
      bestBlob = blob;
      lo = mid;
    } else {
      hi = mid;
    }
    if (hi - lo < 0.01) break;
  }

  // If we never hit target, use lowest quality
  if (!bestBlob) {
    bestBlob = await canvasToBlob(0.05);
  }

  return bestBlob;
}

/**
 * Promisified canvas.toBlob for WebP.
 * @param {number} quality 0–1
 * @returns {Promise<Blob>}
 */
function canvasToBlob(quality) {
  return new Promise((resolve, reject) => {
    canvas.toBlob(
      (blob) => blob ? resolve(blob) : reject(new Error('toBlob failed')),
      'image/webp',
      quality
    );
  });
}

/* ══════════════════════════════════════════════════════════════
   SECTION NAVIGATION
══════════════════════════════════════════════════════════════ */
function showSection(id) {
  [uploadSection, queueSection, resultsSection].forEach(s => {
    s.classList.toggle('active', s.id === id);
    s.classList.toggle('hidden', s.id !== id);
  });
}

/* ══════════════════════════════════════════════════════════════
   FILE HANDLING
══════════════════════════════════════════════════════════════ */

/**
 * Filter & validate files; add accepted ones to queue.
 * @param {FileList|File[]} files
 */
function addFilesToQueue(files) {
  const fileArray = Array.from(files);
  const valid = fileArray.filter(f => ACCEPTED_TYPES.has(f.type) || /\.(jpe?g|png|gif|bmp|svg|webp)$/i.test(f.name));

  if (valid.length === 0) return;

  valid.forEach(file => {
    // Avoid duplicates by name+size
    const exists = queue.some(q => q.file.name === file.name && q.file.size === file.size);
    if (!exists) {
      queue.push({ file, objectUrl: URL.createObjectURL(file) });
    }
  });

  renderQueue();
  showSection('queue-section');
}

/**
 * Render all queue items to the DOM.
 */
function renderQueue() {
  queueList.innerHTML = '';
  queueCount.textContent = `${queue.length} image${queue.length !== 1 ? 's' : ''}`;

  queue.forEach((item, index) => {
    const div = document.createElement('div');
    div.className = 'queue-item';
    div.dataset.index = index;

    const thumb = document.createElement('img');
    thumb.className = 'queue-thumb';
    thumb.src = item.objectUrl;
    thumb.alt = item.file.name;

    const info = document.createElement('div');
    info.className = 'queue-info';

    const name = document.createElement('div');
    name.className = 'queue-name';
    name.textContent = item.file.name;
    name.title = item.file.name;

    const size = document.createElement('div');
    size.className = 'queue-size';
    size.textContent = formatSize(item.file.size);

    info.append(name, size);

    const removeBtn = document.createElement('button');
    removeBtn.className = 'queue-remove';
    removeBtn.title = 'Remove';
    removeBtn.innerHTML = `<svg width="12" height="12" viewBox="0 0 24 24" fill="none"><path d="M18 6L6 18M6 6l12 12" stroke="currentColor" stroke-width="2" stroke-linecap="round"/></svg>`;
    removeBtn.addEventListener('click', () => removeFromQueue(index));

    div.append(thumb, info, removeBtn);
    queueList.appendChild(div);
  });
}

/**
 * Remove a single item from the queue.
 * @param {number} index
 */
function removeFromQueue(index) {
  URL.revokeObjectURL(queue[index].objectUrl);
  queue.splice(index, 1);

  if (queue.length === 0) {
    showSection('upload-section');
  } else {
    renderQueue();
  }
}

/* ══════════════════════════════════════════════════════════════
   CONVERSION ENGINE
══════════════════════════════════════════════════════════════ */

/**
 * Convert all queued images sequentially.
 */
async function convertAll() {
  if (queue.length === 0) return;

  const targetBytes = getTargetBytes();
  const maxWidth    = getMaxWidth();
  results = [];

  // Show progress overlay
  progressOverlay.classList.remove('hidden');
  progressBar.style.width = '0%';
  progressSub.textContent = `0 / ${queue.length}`;

  for (let i = 0; i < queue.length; i++) {
    const item = queue[i];
    progressLabel.textContent = `Converting ${item.file.name}`;
    progressSub.textContent   = `${i} / ${queue.length}`;
    progressBar.style.width   = `${(i / queue.length) * 100}%`;

    try {
      const img    = await loadImage(item.file);
      let drawW    = img.naturalWidth;
      let drawH    = img.naturalHeight;

      // Resize if maxWidth is set
      if (maxWidth > 0 && drawW > maxWidth) {
        drawH = Math.round((drawH / drawW) * maxWidth);
        drawW = maxWidth;
      }

      const blob = await compressToTarget(img, drawW, drawH, targetBytes);
      const previewUrl = URL.createObjectURL(blob);

      results.push({
        name:          seoFilename(item.file.name),
        originalName:  item.file.name,
        originalSize:  item.file.size,
        convertedSize: blob.size,
        blob,
        previewUrl,
      });

      // Clean up image object URL
      URL.revokeObjectURL(img.src);
    } catch (err) {
      console.error(`Failed to convert ${item.file.name}:`, err);
      results.push({
        name:          seoFilename(item.file.name),
        originalName:  item.file.name,
        originalSize:  item.file.size,
        convertedSize: 0,
        blob:          null,
        previewUrl:    item.objectUrl,
        error:         err.message,
      });
    }
  }

  progressBar.style.width = '100%';
  progressSub.textContent = `${queue.length} / ${queue.length}`;

  // Brief pause before hiding overlay
  await delay(400);
  progressOverlay.classList.add('hidden');

  renderResults();
  showSection('results-section');
}

/**
 * Simple delay helper.
 * @param {number} ms
 */
function delay(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

/* ══════════════════════════════════════════════════════════════
   RESULTS RENDERING
══════════════════════════════════════════════════════════════ */

/**
 * Render all results to the DOM.
 */
function renderResults() {
  resultsListEl.innerHTML = '';

  results.forEach((result, index) => {
    const item = document.createElement('div');
    item.className = 'result-item';
    item.style.animationDelay = `${index * 0.06}s`;

    if (result.error) {
      const body = document.createElement('div');
      body.className = 'result-body';

      const name = document.createElement('div');
      name.className = 'result-name';
      name.textContent = result.originalName;
      name.title = result.originalName;

      const stats = document.createElement('div');
      stats.className = 'result-stats result-error';

      const status = document.createElement('div');
      status.className = 'stat';
      const statusLabel = document.createElement('span');
      statusLabel.className = 'stat-label';
      statusLabel.textContent = 'Status';
      const statusValue = document.createElement('span');
      statusValue.className = 'stat-value';
      statusValue.textContent = 'Failed';
      status.append(statusLabel, statusValue);

      const error = document.createElement('div');
      error.className = 'stat';
      const errorLabel = document.createElement('span');
      errorLabel.className = 'stat-label';
      errorLabel.textContent = 'Error';
      const errorValue = document.createElement('span');
      errorValue.className = 'stat-value';
      errorValue.textContent = result.error;
      error.append(errorLabel, errorValue);

      stats.append(status, error);
      body.append(name, stats);
      item.appendChild(body);
      resultsListEl.appendChild(item);
      return;
    }

    const savings = result.originalSize > 0
      ? Math.round((1 - result.convertedSize / result.originalSize) * 100)
      : 0;

    const savingsDisplay = savings > 0 ? `-${savings}%` : savings < 0 ? `+${Math.abs(savings)}%` : '0%';
    const savingClass    = savings > 0 ? 'stat-saving' : '';

    // Preview image
    const preview = document.createElement('img');
    preview.className = 'result-preview';
    preview.src = result.previewUrl;
    preview.alt = result.name;

    // Body
    const body = document.createElement('div');
    body.className = 'result-body';
    body.innerHTML = `
      <div class="result-name" title="${result.name}">${result.name}</div>
      <div class="result-stats">
        <div class="stat">
          <span class="stat-label">Original</span>
          <span class="stat-value">${formatSize(result.originalSize)}</span>
        </div>
        <div class="stat">
          <span class="stat-label">WebP</span>
          <span class="stat-value">${formatSize(result.convertedSize)}</span>
        </div>
        <div class="stat ${savingClass}">
          <span class="stat-label">Saved</span>
          <span class="stat-value">${savingsDisplay}</span>
        </div>
      </div>`;

    // Download button
    const dlBtn = document.createElement('button');
    dlBtn.className = 'btn-download';
    dlBtn.innerHTML = `
      <svg width="12" height="12" viewBox="0 0 24 24" fill="none"><path d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>
      Download ${result.name}`;
    dlBtn.addEventListener('click', () => downloadResult(result));
    body.appendChild(dlBtn);

    item.append(preview, body);
    resultsListEl.appendChild(item);
  });
}

/**
 * Trigger a download for a single result.
 * @param {{ name: string, blob: Blob }} result
 */
function downloadResult(result) {
  if (!result.blob) return;
  const url = URL.createObjectURL(result.blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = result.name;
  a.click();
  // Revoke after brief delay
  setTimeout(() => URL.revokeObjectURL(url), 2000);
}

/**
 * Download all results as individual files.
 * Staggers downloads slightly to avoid browser blocking.
 */
async function downloadAll() {
  const successful = results.filter(r => r.blob);
  for (let i = 0; i < successful.length; i++) {
    await delay(i * 150);
    downloadResult(successful[i]);
  }
}

/* ══════════════════════════════════════════════════════════════
   RESET / CONVERT MORE
══════════════════════════════════════════════════════════════ */
function resetAll() {
  // Revoke all object URLs
  queue.forEach(q => URL.revokeObjectURL(q.objectUrl));
  results.forEach(r => {
    if (r.previewUrl) URL.revokeObjectURL(r.previewUrl);
    if (r.blob) URL.revokeObjectURL(r.previewUrl);
  });

  queue   = [];
  results = [];

  queueList.innerHTML     = '';
  resultsListEl.innerHTML = '';
  fileInput.value         = '';
  addMoreInput.value      = '';

  showSection('upload-section');
}

/* ══════════════════════════════════════════════════════════════
   EVENT LISTENERS
══════════════════════════════════════════════════════════════ */

// ── Drop zone click ──
dropZone.addEventListener('click', () => fileInput.click());
dropZone.addEventListener('keydown', (e) => {
  if (e.key === 'Enter' || e.key === ' ') {
    e.preventDefault();
    fileInput.click();
  }
});

// ── File input change ──
fileInput.addEventListener('change', (e) => {
  if (e.target.files.length > 0) addFilesToQueue(e.target.files);
});

// ── Drag & drop ──
dropZone.addEventListener('dragenter', (e) => {
  e.preventDefault();
  dropZone.classList.add('drag-over');
});

dropZone.addEventListener('dragover', (e) => {
  e.preventDefault();
  dropZone.classList.add('drag-over');
});

dropZone.addEventListener('dragleave', (e) => {
  if (!dropZone.contains(e.relatedTarget)) {
    dropZone.classList.remove('drag-over');
  }
});

dropZone.addEventListener('drop', (e) => {
  e.preventDefault();
  dropZone.classList.remove('drag-over');
  const files = e.dataTransfer?.files;
  if (files && files.length > 0) addFilesToQueue(files);
});

// ── Size select toggle ──
sizeSelect.addEventListener('change', () => {
  customSizeWrap.classList.toggle('hidden', sizeSelect.value !== 'custom');
});

// ── Convert all button ──
convertAllBtn.addEventListener('click', convertAll);

// ── Add more button ──
addMoreBtn.addEventListener('click', () => addMoreInput.click());
addMoreInput.addEventListener('change', (e) => {
  if (e.target.files.length > 0) addFilesToQueue(e.target.files);
  addMoreInput.value = '';
});

// ── Download all ──
downloadAllBtn.addEventListener('click', downloadAll);

// ── Convert more ──
convertMoreBtn.addEventListener('click', resetAll);

// ── Paste support (paste image from clipboard) ──
document.addEventListener('paste', (e) => {
  const items = Array.from(e.clipboardData?.items || []);
  const imageItems = items.filter(i => i.type.startsWith('image/'));
  if (imageItems.length > 0) {
    const files = imageItems.map(i => i.getAsFile()).filter(Boolean);
    addFilesToQueue(files);
  }
});
